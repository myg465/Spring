package com.javalec.ex;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Medical_record implements InitializingBean,DisposableBean{

	//회원번호,날짜,치료-감기증상,담당의사,담당간호사
	//다음방문예약
	
	public Medical_record() {}
	
	public Medical_record(int mem_num, String date, String cure,
			String doc, String nurse, String nextdate) {
		this.mem_num = mem_num;
		this.date = date;
		this.cure = cure;
		this.doc = doc;
		this.nurse = nurse;
		this.nextdate = nextdate;
	}


	private int mem_num;
	private String date;
	private String cure;
	private String doc;
	private String nurse;
	private String nextdate;
	
	//getter/setter부분
	public int getMem_num() {
		return mem_num;
	}

	public void setMem_num(int mem_num) {
		this.mem_num = mem_num;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCure() {
		return cure;
	}

	public void setCure(String cure) {
		this.cure = cure;
	}

	public String getDoc() {
		return doc;
	}

	public void setDoc(String doc) {
		this.doc = doc;
	}

	public String getNurse() {
		return nurse;
	}

	public void setNurse(String nurse) {
		this.nurse = nurse;
	}

	public String getNextdate() {
		return nextdate;
	}

	public void setNextdate(String nextdate) {
		this.nextdate = nextdate;
	}

	//생명주기 부분
	public void afterPropertiesSet() throws Exception {
		System.out.println("Medical_record afterPropertiesSet()실행됨");
		
	}
	
	public void destroy() throws Exception {
		System.out.println("Medical_record destroy()실행됨");
		
	}
	
	
}
