package com.javalec.ex;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Member implements InitializingBean,DisposableBean{

	
	public Member() {}
	
	
	public Member(int mem_num, String name, int age, String gender,
			String tel, String address, String record) {
		this.mem_num = mem_num;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.tel = tel;
		this.address = address;
		this.record = record;
	}


	private int mem_num;
	private String name;
	private int age;
	private String gender;
	private String tel;
	private String address;
	private String record;
	
	public int getMem_num() {
		return mem_num;
	}

	public void setMem_num(int mem_num) {
		this.mem_num = mem_num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRecord() {
		return record;
	}

	public void setRecord(String record) {
		this.record = record;
	}
	

	public void afterPropertiesSet() throws Exception {
		System.out.println("Member afterPropertiesSet()실행됨");
		
	}
	
	public void destroy() throws Exception {
		System.out.println("Member destroy()실행됨");
		
	}


}
