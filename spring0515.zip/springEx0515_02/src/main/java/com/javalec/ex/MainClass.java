package com.javalec.ex;

import java.util.ArrayList;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext ctx=new GenericXmlApplicationContext();
		ctx.load("classpath:appCTX.xml");
		ctx.refresh();
		
		Member_all list_=ctx.getBean("member_all",Member_all.class);
		ArrayList<Member> list=list_.getList();
		Medical_record record1=ctx.getBean("medical_record1",Medical_record.class);
		Medical_record record2=ctx.getBean("medical_record2",Medical_record.class);
		
		for(int i=0;i<list.size();i++) {
			Member member=list.get(i);
			if(member.getMem_num()==record2.getMem_num()) {
				System.out.println("회원번호 : "+member.getMem_num());
				System.out.println("회원이름 : "+member.getName());
				System.out.println("회원나이 : "+member.getAge());
				System.out.println("회원성별 : "+member.getGender());
				System.out.println("회원연락처 : "+member.getTel());
				System.out.println("회원주소 : "+member.getAddress());
				System.out.println("수술기록 : "+member.getRecord());
				System.out.println("----------------------------------");
				System.out.println("치료날짜 : "+record2.getDate());
				System.out.println("치료내용 : "+record2.getCure());
				System.out.println("담당의사 : "+record2.getDoc());
				System.out.println("담당간호사 : "+record2.getNurse());
				System.out.println("다음예약 : "+record2.getNextdate());
	
			}//if
			
		}//for
		
		ctx.close();

	}//main

}//class
