package com.javalec.ex;

import java.io.IOException;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.io.support.ResourcePropertySource;

public class MainClass {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = new GenericXmlApplicationContext();
		ConfigurableEnvironment env =ctx.getEnvironment();
		MutablePropertySources propertySource = env.getPropertySources();
		try {
			propertySource.addLast(new ResourcePropertySource("classpath:admin.properties"));//propertySource에 추가
                            		} catch (IOException e) {
			e.printStackTrace();
		}
		
		GenericXmlApplicationContext ctx2 = (GenericXmlApplicationContext)ctx;//자손으로 형변환(ConfigurableApplicationContext가 조상)
		
		ctx2.load("appCTX.xml");
		ctx2.refresh();//AdminConnection-> init 메소드가 실행 -> id,pw에 값이 할당
		AdminConnection adminConnection = ctx2.getBean("adminConnection",AdminConnection.class);//id,pw,env값이 들어가 있는 객체를 가져옴
		
		System.out.println("ID : "+ adminConnection.getAdminId());
		System.out.println("PW : "+ adminConnection.getAdminPw());
		
		ctx2.close();
		ctx.close();
		
	}//main

}//class
