package com.javalec.ex;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;

public class AdminConnection implements EnvironmentAware,InitializingBean,DisposableBean{

	Environment env;
	String adminId;
	String adminPw;
	
	public void setEnv(Environment env) {
		this.env = env;
	}
	
	

	public String getAdminId() {
		return adminId;
	}



	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}



	public String getAdminPw() {
		return adminPw;
	}



	public void setAdminPw(String adminPw) {
		this.adminPw = adminPw;
	}



	public void setEnvironment(Environment env) {
		System.out.println("AdminConnection env에 값을 설정");
		setEnv(env);
		
	}
	
	public void afterPropertiesSet() throws Exception {
		System.out.println("AdminConnection실행시 init 실행 메소드");
		setAdminId(env.getProperty("admin.id"));
		setAdminPw(env.getProperty("admin.pw"));
	}
	
	public void destroy() throws Exception {
		System.out.println("AdminConnection종료시 destory 실행 메소드");
	}


}
