package com.javalec.ex;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;

public class AdminConnection implements EnvironmentAware,InitializingBean,DisposableBean{

	
	private Environment env;
	private String adminId;
	private String adminPw;
	
	
	//AdminConnection 시작전 실행해서 값을 할당(env에는 이미 값이 있다)
	public void setEnvironment(Environment env) {
		
		System.out.println("setEnvironment 설정됨");
		setEnv(env);//this.env=env랑 같음 (이 클래스 안의 env에 값을 넣는다.)
		
	}
	
	//init()객체 생성시 실행 (생성되자마자 env에 있는 값을 adminId,adminPw에 넣어줌)
	public void afterPropertiesSet() throws Exception {
		
		System.out.println("객체 생성시 admin_id,pw 값을 할당");
		
		setAdminId(env.getProperty("admin.id"));//env에 있는 admin_id를 찾아 adminId에 할당
		setAdminPw(env.getProperty("admin.pw"));//env에 있는 admin_pw를 찾아 adminPw에 할당
		
	}
	
	public void destroy() throws Exception {
		
		System.out.println("빈 객체 종료");
	}
	
	
	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getAdminPw() {
		return adminPw;
	}

	public void setAdminPw(String adminPw) {
		this.adminPw = adminPw;
	}
	
	
}
