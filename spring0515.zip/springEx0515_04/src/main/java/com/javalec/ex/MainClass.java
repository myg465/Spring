package com.javalec.ex;

import java.io.IOException;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.io.support.ResourcePropertySource;

public class MainClass {

	public static void main(String[] args) {

		ConfigurableApplicationContext ctx = new GenericXmlApplicationContext();
		ConfigurableEnvironment env = ctx.getEnvironment();//외부환경의 리스트를 뽑아옴
		MutablePropertySources propertySource = env.getPropertySources();//파일을 넣을 곳을 가져옴(순서가 없는 리스트-> 추가를 하면 맨뒤에 추가됨)
		
		try {
			propertySource.addLast(new ResourcePropertySource("classpath:admin.properties")); 
			System.out.println(env.getProperty("admin.id"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		GenericXmlApplicationContext ctx2=(GenericXmlApplicationContext)ctx; //주소를 넘겨줌
		ctx2.load("classpath:appCTX.xml");
		ctx2.refresh();//이 단계에서 값이 들어감
		
		AdminConnection adminConnection = ctx2.getBean("adminConnection",AdminConnection.class);// 빈을 호출하기전에 이미 값이 넣어져있음
		
		
		System.out.println("아이디 : "+adminConnection.getAdminId());
		System.out.println("비밀번호 : "+adminConnection.getAdminPw());
		
		ctx.close();
		ctx2.close();
		
		
	}

}
