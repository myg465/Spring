package com.javalec.ex;

public interface Car {
    public void run();
    public void stop();
    public void use();
}
