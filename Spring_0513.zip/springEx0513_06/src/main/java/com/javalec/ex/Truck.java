package com.javalec.ex;

public class Truck implements Car {

	public void run() {
		System.out.println("시속 200키로로 달립니다.");
		
	}

	public void stop() {
		System.out.println("느리게 멈춥니다.");
		
	}

	public void use() {
		System.out.println("짐을 옮깁니다.");
		
	}

}
