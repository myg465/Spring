package com.javalec.ex;

public class ambulence implements Car {

	public void run() {
		System.out.println("시속 300키로로 달립니다.");
		
	}

	public void stop() {
		System.out.println("엄청빨리 멈춥니다.");
		
	}

	public void use() {
		System.out.println("싸이렌이 울립니다.");
		
	}

}
