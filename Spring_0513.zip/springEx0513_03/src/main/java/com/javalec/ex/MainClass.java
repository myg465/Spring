package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {

		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:appCTX.xml");
		MyInfo myInfo = ctx.getBean("myInfo",MyInfo.class);
		
		myInfo.getInfo();//정보를 찍어줌
		
	}

}
//log4j:WARN No appenders could be found for logger (org.springframework.beans.factory.xml.XmlBeanDefinitionReader).
//log4j:WARN Please initialize the log4j system properly.