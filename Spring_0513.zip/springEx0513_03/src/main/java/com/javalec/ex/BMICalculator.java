package com.javalec.ex;

public class BMICalculator {

	private double lowWeight;//저체중
	private double normal;//보통
	private double overWeight;//과체중
	private double obesity;//비만
	
	public void bmicalculator(double weight,double height) {
		
		double h = height*0.01;
		double result = weight/(h*h);//bmi지수
		
		System.out.println("당신의 BMI지수는"+result+"입니다.");
		
		if(result>obesity) {
			System.out.println("비만입니다.");
		}
		else if(result>overWeight) {
			System.out.println("과체중입니다.");
		}
		else if(result>normal) {
			System.out.println("보통입니다.");
		}
		else {
			System.out.println("저체중입니다.");
		}
	}

	public void setLowWeight(double lowWeight) {
		this.lowWeight = lowWeight;
	}

	public void setNormal(double normal) {
		this.normal = normal;
	}

	public void setOverWeight(double overWeight) {
		this.overWeight = overWeight;
	}

	public void setObesity(double obesity) {
		this.obesity = obesity;
	}
	
	
	
	
}
