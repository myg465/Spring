package com.javalec.ex;

public class Pensil4B implements Pencil {

	public void use() {
		System.out.println("Pencil4B");
		System.out.println("Pencil4B굵기 기능을 가지고 있습니다.");

	}

}
