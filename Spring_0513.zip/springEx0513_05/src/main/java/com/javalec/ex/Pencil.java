package com.javalec.ex;

public interface Pencil {
	public void use();
}
