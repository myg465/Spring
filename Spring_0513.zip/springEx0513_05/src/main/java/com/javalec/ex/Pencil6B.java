package com.javalec.ex;

public class Pencil6B implements Pencil {

	public void use() {
		System.out.println("Pencil6B");
		System.out.println("Pencil6B굵기 기능을 가지고 있습니다.");

	}

}
