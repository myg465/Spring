package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		String configLocation="classpath:applicationCTX.xml";
		AbstractApplicationContext ctx= new GenericXmlApplicationContext(configLocation);
		
		Stu_score stu_score=ctx.getBean("stu_score",Stu_score.class);
		stu_score.stu_num();
		stu_score.stu_name();
		stu_score.kor();
		stu_score.eng();
		stu_score.math();
		stu_score.total();
		stu_score.avg();
		stu_score.grade();
		
	}
	
}
