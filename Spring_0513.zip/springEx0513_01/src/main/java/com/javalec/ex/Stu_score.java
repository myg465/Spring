package com.javalec.ex;

public class Stu_score {

	//--stu_num,stu_name,kor,eng,math,total,avg
	//--Score_process 객체
	
	//변수선언
	int stu_num;
	String stu_name;
	int kor;
	int eng;
	int math;
	int total;
	double avg;
	
	Stu_process stu_process=new Stu_process();
	//게터세터선언
	public void setStu_num(int stu_num) {
		this.stu_num = stu_num;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

	public void setStu_process(Stu_process stu_process) {
		this.stu_process = stu_process;
	}
	
	//stu_process의 메소드를 부르는 메소드
	public void stu_num() {
		stu_process.stu_num(stu_num);
	}
	public void stu_name() {
		stu_process.stu_name(stu_name);
	}
	public void kor() {
		stu_process.kor(kor);
	}
	public void eng() {
		stu_process.eng(eng);
	}
	public void math() {
		stu_process.math(math);
	}
	public void total() {
		stu_process.total(total);
	}
	public void avg() {
		stu_process.avg(avg);
	}
	public void grade() {
		stu_process.grade(avg);
	}
	
	
	
	
	
}
