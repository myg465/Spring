package com.javalec.ex;

public interface Service {
	
	String getMessage();

}
