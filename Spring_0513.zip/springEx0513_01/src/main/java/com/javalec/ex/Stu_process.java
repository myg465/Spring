package com.javalec.ex;

public class Stu_process {

	public void stu_num(int stu_num) {
		System.out.println("학번 : "+stu_num);
	}
	public void stu_name(String stu_name) {
		System.out.println("이름 : "+stu_name);
	}
	public void kor(int kor) {
		System.out.println("수학성적 : "+kor);
	}
	public void eng(int eng) {
		System.out.println("영어성적 : "+eng);
	}
	public void math(int math) {
		System.out.println("수학성적 : "+math);
	}
	public void total(int total) {
		System.out.println("합계 : "+total);
	}
	public void avg(double avg) {
		System.out.println("평균 : "+avg);
	}
	
	public void grade(double avg) {
		String grade="";
		if(avg>=90) { grade="A";}
		else if(avg>=80) { grade="B";}
		else if(avg>=70) { grade="C";}
		else if(avg>=60) { grade="D";}
		else {grade="F";}
		
		System.out.println(grade+"등급입니다.");
	}
	
	
	
	
}
