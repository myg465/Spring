package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		//ctx->ioc컨테이너(컨테이너를 부르고 그걸 활용하여)
		AbstractApplicationContext ctx=new GenericXmlApplicationContext("classpath:appCTX.xml");
		StudentInfo studentInfo=ctx.getBean("studentinfo",StudentInfo.class);
		//생성자에 의한 주입-> 출력
		studentInfo.getStudentInfo();
		
		//setter
		Student student2 = ctx.getBean("student2",Student.class);//xml에서 student2를 들고옴
		studentInfo.setStudent(student2);
		//setter에 의한 주입-> 출력
		studentInfo.getStudentInfo();
		
		//꼭 닫아야함(안닫으면 자원차지)
		ctx.close();
		
		

	}

}
