package com.javalec.ex;

public class Calculator {

	public void nature(String nature) {
		System.out.println("국가이름 : "+nature);
	}
	
	public void tempchange(int temp) {
		double result;
		result=(1.8*temp)+32;
		System.out.println("화씨온도 : "+result+"F");
	}
	
	
}
