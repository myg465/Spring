package com.javalec.ex;

public class Temperature {

	String nature;
	int temp;
	
	Calculator calculator = new Calculator();

	public void setNature(String nature) {
		this.nature = nature;
	}

	public void setTemp(int temp) {
		this.temp = temp;
	}

	public void setCalculator(Calculator calculator) {
		this.calculator = calculator;
	}
	
	public void nature() {
		calculator.nature(nature);
	}
	
	public void tempchange() {
		calculator.tempchange(temp);
	}
	
	
	
	
}
