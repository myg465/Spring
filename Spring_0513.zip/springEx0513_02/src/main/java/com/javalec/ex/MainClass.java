package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:appCTX.xml");
		
		Temperature temp = ctx.getBean("temperature",Temperature.class);
		temp.setNature("중국");
		temp.nature();
		temp.tempchange();
		Temperature temp2 = ctx.getBean("temperature",Temperature.class);
		temp.nature(); //하나가 바뀌면 같이바뀐다.
		
	}
	
}
//log4j:WARN No appenders could be found for logger (org.springframework.beans.factory.xml.XmlBeanDefinitionReader).
//log4j:WARN Please initialize the log4j system properly.
