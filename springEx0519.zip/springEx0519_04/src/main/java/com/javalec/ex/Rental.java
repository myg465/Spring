package com.javalec.ex;

public class Rental {

	
	int r_num;
	String r_name;
	String r_book;
	String r_date;
	String r_tel;
	
	public void r_print() {
		System.out.println("대여 정보 : "+r_num+"/"+r_book+"/"+r_name+"/"+r_date+"/"+r_tel);
	}
	
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public String getR_name() {
		return r_name;
	}
	public void setR_name(String r_name) {
		this.r_name = r_name;
	}
	public String getR_book() {
		return r_book;
	}
	public void setR_book(String r_book) {
		this.r_book = r_book;
	}
	public String getR_date() {
		return r_date;
	}
	public void setR_date(String r_date) {
		this.r_date = r_date;
	}
	public String getR_tel() {
		return r_tel;
	}
	public void setR_tel(String r_tel) {
		this.r_tel = r_tel;
	}
	
	
	
}
