package com.javalec.ex;

public class Book {

	
	int b_num;
	String b_name;
	String b_category;
	String b_auth;
	
	public void b_print() {
		System.out.println("책정보 : "+b_num+"/"+b_name+"/"+b_category+"/"+b_auth);
	}
	
	public int getB_num() {
		return b_num;
	}
	public void setB_num(int b_num) {
		this.b_num = b_num;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_category() {
		return b_category;
	}
	public void setB_category(String b_category) {
		this.b_category = b_category;
	}
	public String getB_auth() {
		return b_auth;
	}
	public void setB_auth(String b_auth) {
		this.b_auth = b_auth;
	}
	
	
}
