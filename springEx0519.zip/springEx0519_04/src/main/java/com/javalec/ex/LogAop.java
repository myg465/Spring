package com.javalec.ex;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LogAop {

	@Pointcut("within(com.javalec.ex.*)")
	private void pointCutMethod() {
	}

	@Before("within(com.javalec.ex.Rental)")
	public void beforeadvice() {
	
		System.out.println("시작시간(before) : "+System.currentTimeMillis());
	
	}//before
	
	@After("pointCutMethod()")
	public void afteradvice() {
		
		System.out.println("종료시간(after) : "+System.currentTimeMillis());
	
	}//after
	
	@Around("within(com.javalec.ex.Book)")
	public Object loggerAop(ProceedingJoinPoint joinpoint) throws Throwable{
		
		long starttime = System.currentTimeMillis();
		
		System.out.println("시작시간(around) : "+starttime);
		
		try {
			return joinpoint.proceed();
		}
		finally {
			long endtime =System.currentTimeMillis();
			System.out.println("경과시간(around) : "+(endtime-starttime));
		}
	
	}//around
	
	
}
