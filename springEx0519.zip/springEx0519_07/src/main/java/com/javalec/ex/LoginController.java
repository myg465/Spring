package com.javalec.ex;

public class LoginController {

}
