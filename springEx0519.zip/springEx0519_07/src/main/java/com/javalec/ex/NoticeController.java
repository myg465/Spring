package com.javalec.ex;

public class NoticeController {

}
