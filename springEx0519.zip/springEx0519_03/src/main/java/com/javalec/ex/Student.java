package com.javalec.ex;

public class Student {

	int stuNum;
	String name;
	String gradeNum;
	String classNum;
	
	public void stu_print() {
		
		System.out.println("학생정보 : "+stuNum+"/"+name);
		
	}
	
	
	
	public int getStuNum() {
		return stuNum;
	}
	public void setStuNum(int stuNum) {
		this.stuNum = stuNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGradeNum() {
		return gradeNum;
	}
	public void setGradeNum(String gradeNum) {
		this.gradeNum = gradeNum;
	}
	public String getClassNum() {
		return classNum;
	}
	public void setClassNum(String classNum) {
		this.classNum = classNum;
	}
	
	
	
}
