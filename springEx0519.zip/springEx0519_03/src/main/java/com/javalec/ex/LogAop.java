package com.javalec.ex;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect //aspect 선언
public class LogAop {

	@Pointcut("within(com.javalec.ex.*)") // 범위 지정
	private void pointcutMethod() {
	}
	
	@Around("pointcutMethod()") // pointcut메소드에 정한대로 범위를 정한다.(다르게 지정할수도 있음)
	public Object loggerAop(ProceedingJoinPoint joinPoint) throws Throwable {
		
		System.out.println("(around)시작시간 : "+System.currentTimeMillis());
		
		try {
			
			return joinPoint.proceed();
			
		}
		finally {
			
			System.out.println("(around)종료시간 : "+System.currentTimeMillis());
			
		}
	}//around
	
	@Before("within(com.javalec.ex.Worker)")// 워커 클래스 에만 적용하고 싶을때 
	public void beforeAdvice() {
		
		System.out.println("(before) 시작시간 : "+System.currentTimeMillis());
		
	}//beforeAdvice
	

	@After("pointcutMethod()")
	public void afterAdvice() {
		
		System.out.println("(after) 종료시간 : "+System.currentTimeMillis());
		
	}//afterAdvice
	
	
	
}
