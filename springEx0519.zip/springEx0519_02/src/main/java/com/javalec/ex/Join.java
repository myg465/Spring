package com.javalec.ex;

public class Join {

	//회원번호,아이디,패스워드,이름,가입일,(출력)
	
	int j_num;
	String j_id;
	String j_pw;
	String j_name;
	String j_date;
	
	public void j_print() {
		System.out.println("회원정보 출력 : "+ j_num+"/"+j_id+"/"+j_pw+"/"+j_name+"/"+j_date);
	}
	
	
	public int getJ_num() {
		return j_num;
	}
	public void setJ_num(int j_num) {
		this.j_num = j_num;
	}
	public String getJ_id() {
		return j_id;
	}
	public void setJ_id(String j_id) {
		this.j_id = j_id;
	}
	public String getJ_pw() {
		return j_pw;
	}
	public void setJ_pw(String j_pw) {
		this.j_pw = j_pw;
	}
	public String getJ_name() {
		return j_name;
	}
	public void setJ_name(String j_name) {
		this.j_name = j_name;
	}
	public String getJ_date() {
		return j_date;
	}
	public void setJ_date(String j_date) {
		this.j_date = j_date;
	}
	
	
	
}
