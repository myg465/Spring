package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:appCTX.xml");
		
		Noticeboard noticeboard = ctx.getBean("noticeboard",Noticeboard.class);
		noticeboard.n_print();
		
		Eventboard eventboard = ctx.getBean("eventboard",Eventboard.class);
		eventboard.e_print();
		
		Join join = ctx.getBean("join",Join.class);
		join.j_print();

	}

}
