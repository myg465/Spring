package com.javalec.ex;

import org.aspectj.lang.ProceedingJoinPoint;

public class LogAop {

	//around
	public Object loggerAop(ProceedingJoinPoint joinPoint) throws Throwable{
		
		System.out.println("(around)시작시간 : "+System.currentTimeMillis());
		
		try {
			
			return joinPoint.proceed();
		}
		finally {
			
			System.out.println("(around)종료시간 : "+System.currentTimeMillis());
			
		}
	}//loggerAop
	
	public void beforeadvice() {
		System.out.println("(before) 시작시간 : "+ System.currentTimeMillis());
	}//beforeadvice
	
	public void afteradvice() {
		System.out.println("(after) 종료시간 : "+ System.currentTimeMillis());
	}
	
	
	
	
	
	
}
