package com.javalec.ex;

public class Eventboard {

	int e_num;
	String e_title;
	String e_content;
	String e_start;
	String e_end;
	
	public void e_print() {
		System.out.println("이벤트 출력 : "+e_num+"/"+e_title+"/"+e_content+"/"+e_start+"/"+e_end);
	}
	
	public int getE_num() {
		return e_num;
	}
	public void setE_num(int e_num) {
		this.e_num = e_num;
	}
	public String getE_title() {
		return e_title;
	}
	public void setE_title(String e_title) {
		this.e_title = e_title;
	}
	public String getE_content() {
		return e_content;
	}
	public void setE_content(String e_content) {
		this.e_content = e_content;
	}
	public String getE_start() {
		return e_start;
	}
	public void setE_start(String e_start) {
		this.e_start = e_start;
	}
	public String getE_end() {
		return e_end;
	}
	public void setE_end(String e_end) {
		this.e_end = e_end;
	}
	
	
	
	
}
