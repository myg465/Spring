package com.javalec.ex;

import org.aspectj.lang.ProceedingJoinPoint;

public class LogAop {

	//앞뒤로 로그를 찍는 메소드(around)
	public Object loggerAop(ProceedingJoinPoint joinpoint) throws Throwable {
		//시작전 실행 명령
		System.out.println("(around)메소드 시작시간 : "+System.currentTimeMillis());
		
		try {
			
			return joinpoint.proceed(); //실행메소드 호출
			
		}
		finally {
			
			System.out.println("(around)메소드 종료시간 :"+System.currentTimeMillis());
			
		}
		
	}//loggerAop
	
	//시작때만 실행(before)
	public void beforeadvice() {
		
		System.out.println("(before)메소드 시작시간 :"+System.currentTimeMillis());
		
	}//beforeadvice
	
}//class
