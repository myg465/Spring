package com.javalec.ex;

public class DoctorRecord {

	int memberNum;
	String memName;
	String doctor;
	String date;
	
	
	public void doctor_print() {
		System.out.println("환자 회원 정보 : "+memberNum+"/"+memName);
	}
	
	public int getMemberNum() {
		return memberNum;
	}
	public void setMemberNum(int memberNum) {
		this.memberNum = memberNum;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public String getDoctor() {
		return doctor;
	}
	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	
}
