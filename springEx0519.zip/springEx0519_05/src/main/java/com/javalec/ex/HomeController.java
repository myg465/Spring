package com.javalec.ex;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET) // "/"가 주소임(메인페이지)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);//날짜를 형식에 맞춰서 변환
		
		model.addAttribute("serverTime", formattedDate ); //request객체와 비슷하다.(디스패쳐는 앞에 선언되어있음)
		
		return "home";
	}
	
	@RequestMapping(value = "list" )
	public String list() {
		
		return "list";
		
	}
	
	@RequestMapping(value = "update")
	public String update() {
		
		return "update";
		
	}
	
	
}
