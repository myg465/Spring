package com.javalec.ex;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BController {

	@RequestMapping(value="member/member_list")
	public String member_list() {
		
		return "member/member_list";
		
	}
	
}
