package com.javalec.ex.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {

	public static JdbcTemplate template;
}
