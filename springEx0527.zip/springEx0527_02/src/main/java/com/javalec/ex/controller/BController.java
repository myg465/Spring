package com.javalec.ex.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.ex.dao.IDao;

@Controller
public class BController {
	
	@Autowired
	private SqlSession sqlsession;
	
	@RequestMapping("list")
	public String list(Model model) {
		
		IDao dao = sqlsession.getMapper(IDao.class);
		model.addAttribute("list",dao.list());
		return "list";
		
	}//list
	
	@RequestMapping("write_view")
	public String write_view() {
		return "write_view";
	}
	
	@RequestMapping("write")
	public String write(@RequestParam("bName")String bName, @RequestParam("bTitle")String bTitle, @RequestParam("bContent")String bContent) {
		
		IDao dao = sqlsession.getMapper(IDao.class);
		dao.write(bName, bTitle, bContent);
		
		return "redirect:list";
	}
	
	
	
	

}//class
