package com.javalec.ex.bdao;

import java.sql.*;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.javalec.ex.bdto.BDto;
import com.javalec.ex.util.Constant;

public class BDao {

	//jdbc 템플릿을 쓰기위한 변수
	JdbcTemplate template;

	//생성자
	public BDao() {
		
		//데이터 소스가 담겨있는 템플릿
		template = Constant.template;
		
	}//생성자
	
	
	
	
	public ArrayList<BDto> list() {
		
		String sql="select * from mvc_board order by bGroup desc";
		//커넥션 자동으로 , 어레이리스트에 값을 담는것, 닫는것 자동으로 됨(리턴값이 오브젝트임)
		return (ArrayList<BDto>) template.query(sql, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}//list

	//게시글 얻어오기
	public BDto content_view(String bId) {
		
		//조회수 1증가
		upHit(bId);
		
		String sql="select * from mvc_board where bId="+bId;
		//dto타입으로 받으므로 바로리턴
		return template.queryForObject(sql, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}//content_view
	
	//조회수 증가 메소드
	public void upHit(final String bId) {
		
		String sql="update mvc_board set bHit=bHit+1 where bId=?";
		
		template.update(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, Integer.parseInt(bId));
				
			}
		});
		
	}//upHit
	
	
	
}
