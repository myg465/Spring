package com.javalec.ex.bcontroller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.bcommand.*;
import com.javalec.ex.util.Constant;

@Controller
public class BController {

	
	BCommand bcom=null;
	
	//jdbc템플릿 선언
	public JdbcTemplate template;
	
	@Autowired  // 실행하자마자 자동으로 템플릿을 넣어줌(변수에 해도되고,세터에 해도되고, 생성자에 해도됨)
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		
		Constant.template = this.template;
	}
	
	
	//링크연결
	@RequestMapping("list")
	public String list(Model model) {
		
		bcom=new BListCommand();
		bcom.execute(model);
		return "list";
		
	}//list
	
	@RequestMapping("content_view")
	public String content_view(HttpServletRequest request,Model model) {
		
		//리퀘스트를 담아서 커맨드로 보냄
		model.addAttribute("request",request);
		
		bcom=new BContentCommand();
		bcom.execute(model);
		
		
		return "content_view";
		
	}//content_view
	
	
	
	
	
	
	
	
}
