package com.javalec.ex.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {
	//전역변수 (어디서나 쓸수있다.)
	public static JdbcTemplate template;
	
	
	
}
