package com.javalec.ex.bcommand;

import org.springframework.ui.Model;

public interface BCommand {

	void execute(Model model);
	
}
