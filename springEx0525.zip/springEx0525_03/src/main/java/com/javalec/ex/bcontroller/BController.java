package com.javalec.ex.bcontroller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.bcommand.*;
import com.javalec.ex.bdto.BDto;
import com.javalec.ex.util.Constant;

@Controller
public class BController {

	BCommand bcom=null;
	public JdbcTemplate templete;

	@Autowired
	public void setTemplete(JdbcTemplate templete) {
		this.templete = templete;
		Constant.template=this.templete;
	}
	//-------------------------------------------------------------------------
	@RequestMapping("list")
	public String list(HttpServletRequest request, Model model) {
		
		bcom=new BListCommand();
		bcom.execute(request, model);
		
	
		return "list";
	}
	//-------------------------------------------------------------------------
	@RequestMapping("content_view")
	public String content_view(HttpServletRequest request,Model model) {
		
		bcom=new BContentViewCommand();
		bcom.execute(request, model);
		
		return "content_view";
	}
	//-------------------------------------------------------------------------
	@RequestMapping("write")
	public String write(Model model) {
		return "write_view";
	}
	//-------------------------------------------------------------------------
	@RequestMapping("write_view")
	public String write_view(HttpServletRequest request,Model model) {
		
		bcom=new BWriteCommand();
		bcom.execute(request, model);
		
		
		return "redirect:list"; //그냥 list로 넘겨도됨 (차이점 : url의 차이(리다이렉트는 list로 뜬다))
	}//write_view
	//-------------------------------------------------------------------------
	@RequestMapping("delete")
	public String delete(HttpServletRequest request,Model model) {
		
		bcom=new BDeleteCommand();
		bcom.execute(request,model);
		
		return "redirect:list";
	}//delete
	//-------------------------------------------------------------------------
	@RequestMapping("reply_view")
	public String reply_view(HttpServletRequest request, Model model) {
		
		bcom=new BReplyViewCommand();
		bcom.execute(request, model);
		
		return "reply_view";
	}//reply_view
	//-------------------------------------------------------------------------
	@RequestMapping("reply")
	public String reply(HttpServletRequest request, Model model) {
		
		bcom=new BReplyCommand();
		bcom.execute(request, model);
		
		return "redirect:list";
	}//reply
	
	
	
	
	
	
}
