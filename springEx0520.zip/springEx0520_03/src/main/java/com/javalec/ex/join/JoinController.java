package com.javalec.ex.join;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JoinController {
	
	@RequestMapping(method = RequestMethod.POST, value="join/joinOk")
	public ModelAndView joinOk(HttpServletRequest request) {
		
		ModelAndView mv= new ModelAndView();
		
		String j_num = request.getParameter("j_num");
		String j_name = request.getParameter("j_name");
		String j_address = request.getParameter("j_address");
		String j_tel = request.getParameter("j_tel");
		String j_birth = request.getParameter("j_birth");
		
		mv.addObject("j_num", j_num);
		mv.addObject("j_name", j_name);
		mv.addObject("j_address", j_address);
		mv.addObject("j_tel", j_tel);
		mv.addObject("j_birth", j_birth);
		mv.setViewName("join/joinOk");
		
		
		return mv;
	}
	
	@RequestMapping(method = RequestMethod.GET,value="join/joinOk")
	public String joinOk(Model model, HttpServletRequest request) {
		
		String j_num = request.getParameter("j_num");
		String j_name = request.getParameter("j_name");
		String j_address = request.getParameter("j_address");
		String j_tel = request.getParameter("j_tel");
		String j_birth = request.getParameter("j_birth");
		
		model.addAttribute("j_num", j_num);
		model.addAttribute("j_name", j_name);
		model.addAttribute("j_address", j_address);
		model.addAttribute("j_tel", j_tel);
		model.addAttribute("j_birth", j_birth);
		
		return "join/joinOk";
	}
	
	
	
}
