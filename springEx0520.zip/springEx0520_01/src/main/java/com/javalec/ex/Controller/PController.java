package com.javalec.ex.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class PController {

	
	public String productView() {
		
		
		return "";
		
	}
	
	
}
