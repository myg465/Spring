package com.javalec.ex.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EventController {

	
	@RequestMapping(value="/main")
	public String main() {
		return "main";
	}
	
	@RequestMapping("contentView")
	public String contentView() {
		
		return "contentView";
	
	}
	
	@RequestMapping("/event/view")
	public String view(Model model) {
		
		model.addAttribute("id","naver_admin");
		model.addAttribute("pw",1234);
		
		
		
		return "event/view";
	
	}
	
	@RequestMapping("event/modelView")
	public ModelAndView modelView() {
		
		ModelAndView mv = new ModelAndView(); //객체선언
		
		mv.addObject("id","naver_admin");//값을 만듬
		mv.addObject("pw", 1234);
		
		mv.setViewName("event/modelView");//리턴할 주소를 설정
		
		return mv;
		
	}
	
}
