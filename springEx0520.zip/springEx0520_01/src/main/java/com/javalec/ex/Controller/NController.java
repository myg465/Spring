package com.javalec.ex.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/notice") //폴더명을 미리적어줌(리퀘스트 매핑에 공통으로 들어가는것을 정의해줌)
public class NController {

	
	@RequestMapping("/noticeView") //여기서는 그냥 파일명만 적어줘도 됨
	public String noticeView() {
		
		
		return "notice/noticeView";
	}
	
	
	
}
