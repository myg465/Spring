package com.javalec.ex.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class form1Controller {

	@RequestMapping("form1/form1")
	public String form1() {
		return "form1/form1";
	}
	
	@RequestMapping("form1/formOk1")
	public String formOk1(@RequestParam("b_num")int b_num,
			@RequestParam("b_title")String b_title,
			@RequestParam("b_content")String b_content,
			@RequestParam("b_date")String b_date,
			@RequestParam("b_group")int b_group,
			@RequestParam("b_step")int b_step,
			@RequestParam("b_indent")int b_indent,Model model) {
		
		model.addAttribute("b_num",b_num);
		model.addAttribute("b_title",b_title);
		model.addAttribute("b_content",b_content);
		model.addAttribute("b_date",b_date);
		model.addAttribute("b_group",b_group);
		model.addAttribute("b_step",b_step);
		model.addAttribute("b_indent",b_indent);
		
		return "form1/formOk1";
		
	}
	
	
}
