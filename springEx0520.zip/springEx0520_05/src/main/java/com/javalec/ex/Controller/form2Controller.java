package com.javalec.ex.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class form2Controller {

	@RequestMapping("form2/form2")
	public String form2() {
		return "form2/form2";
	}
	
	@RequestMapping("form2/formOk2")
	public String formOk2(HttpServletRequest request,Model model) {
		
		int b_num =Integer.parseInt(request.getParameter("b_num")) ;
		String b_title =request.getParameter("b_title");
		String b_content =request.getParameter("b_content");
		String b_date =request.getParameter("b_date");
		int b_group =Integer.parseInt(request.getParameter("b_group"));
		int b_step =Integer.parseInt(request.getParameter("b_step"));
		int b_indent =Integer.parseInt(request.getParameter("b_indent"));
		
		model.addAttribute("b_num",b_num);
		model.addAttribute("b_title",b_title);
		model.addAttribute("b_content",b_content);
		model.addAttribute("b_date",b_date);
		model.addAttribute("b_group",b_group);
		model.addAttribute("b_step",b_step);
		model.addAttribute("b_indent",b_indent);
		
		return "form2/formOk2";
		
		
	}
	
	
}
