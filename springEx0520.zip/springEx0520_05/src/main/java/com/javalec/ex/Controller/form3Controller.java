package com.javalec.ex.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.Board;

@Controller
public class form3Controller {

	@RequestMapping("form3/form3")
	public String form3() {
		return "form3/form3";
	}
	
	@RequestMapping("form3/formOk3")
	public String formOk3(Board board) {
		
		return "form3/formOk3";
	}
}
