package com.javalec.ex.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.dao.IDao;
import com.javalec.ex.dto.BDto;

@Controller
public class BController {

	@Autowired
	private SqlSession sqlSession;
	
//	@RequestMapping("list")
//	public String list(Model model) {
//		IDao dao = sqlSesstion.getMapper(IDao.class);
//		ArrayList<BDto> dtos = dao.list();
//		model.addAttribute("list", dtos);
//		
//		return "list";
//	}
	
	
	@RequestMapping("list")
	public String list(Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		int page=1;//최초 기본 1페이지 세팅
		int limit=10;//1페이지 = 게시글10개
//		int searchflag=1 ;//검색 체크
		
		//넘어온값이 있으면 넘어온것을 그대로 넘겨줌 / 넘어온값이 없으면 1을 넘겨줌
//		if(request.getParameter("page")!=null) {
//			page = Integer.parseInt((request.getParameter("page"))) ;
//		}
//		
//		int listcount = dao.getlistCount();
//		//최대 페이지수
//		int maxpage = (int)((double)listcount/limit+0.9);
//		//처음 페이지
//		int startpage = ((int)((double)page/10+0.9)-1)*10+1;
//		//마지막 페이지
//		int endpage = maxpage;//1~10까지는 maxpage가 endpage가 되야함
//		if(endpage>startpage+10-1) endpage=startpage+10-1;//만약에 11이상의 수가 endpage라면
		
		model.addAttribute("list",dao.list());
		return "list";
	}
	
	@RequestMapping("write_view")
	public String write_view() {
		return "write_view";
	}
	
	@RequestMapping("write")
	public String write(BDto BDto, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.write(BDto.getbName(), BDto.getbTitle(), BDto.getbContent());
				
		return "redirect:list";
	}
	
	@RequestMapping("content_view")
	public String content_view(HttpServletRequest request, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		
		dao.upHit(request.getParameter("bId"));

		model.addAttribute("content_view", dao.contentView(request.getParameter("bId")));
		
		return "content_view";
	}
	
	@RequestMapping("modify_view")
	public String modify_view(HttpServletRequest request, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		model.addAttribute("modify_view", dao.modifyView(request.getParameter("bId")));
		
		return "modify_view";
	}
	
	@RequestMapping("modify")
	public String modify(BDto BDto, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.modify(""+BDto.getbId(), BDto.getbTitle(), BDto.getbContent());
		
		return "redirect:list";
	}
	
	@RequestMapping("delete")
	public String delete(HttpServletRequest request, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.delete(request.getParameter("bId"));
		
		return "redirect:list";
	}
	
	@RequestMapping("reply_view")
	public String reply_view(HttpServletRequest request, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		model.addAttribute("reply_view", dao.reply_view(request.getParameter("bId")));
		
		return "reply_view";
	}
	
	@RequestMapping("reply")
	public String reply(BDto BDto, Model model) {
		
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.replyshape(""+BDto.getbGroup(), ""+BDto.getbStep());		
		dao.reply(""+BDto.getbId(), BDto.getbName(), BDto.getbTitle(), BDto.getbContent(),
				   ""+BDto.getbGroup(), ""+BDto.getbStep(), ""+BDto.getbIndent());
		
		return "redirect:list";
	}
}
