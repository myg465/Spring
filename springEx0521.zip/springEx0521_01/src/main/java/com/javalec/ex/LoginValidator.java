package com.javalec.ex;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.javalec.ex.dto.LoginDto;

public class LoginValidator implements Validator{

	@Override //검색할 객체
	public boolean supports(Class<?> clazz) {
		
		return LoginDto.class.isAssignableFrom(clazz);
	}

	@Override //검증할 방법을 구현
	public void validate(Object obj, Errors errors) {
		
		LoginDto loginDto = (LoginDto)obj; 
		
//		if(loginDto.getId()==null || loginDto.getId().trim().isEmpty()) {
//			errors.rejectValue("id", "아이디 공백에러"); //에러일경우 에러메세지를 담음
//		}
//		->아래와 같이 바꿀수 있음
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "아이디 공백에러");
		
//		if(loginDto.getId().length()<=3) {
//			errors.rejectValue("idlength", "3자리 이하 에러");
//		}
		
//		if(loginDto.getPw()==null || loginDto.getPw().trim().isEmpty()) {
//			errors.rejectValue("pw", "패스워드 공백에러");
//		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pw", "패스워드 공백에러");
		
		
		
		
	}

}
