package com.javalec.ex.dto;

public class MemberDto {

	String member_id;
	String name;
	String id;
	String pw1;
	String mail_id;
	String mail_tail;
	String f_postal;
	String address1;
	String address2;
	String f_tell;
	String m_tell;
	String l_tell;
	String birth_year;
	String birth_month;
	String birth_day;
	String calendar;
	String gender;
	String newletter;
	String sms;
	
	
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw1() {
		return pw1;
	}
	public void setPw1(String pw1) {
		this.pw1 = pw1;
	}
	public String getMail_id() {
		return mail_id;
	}
	public void setMail_id(String mail_id) {
		this.mail_id = mail_id;
	}
	public String getMail_tail() {
		return mail_tail;
	}
	public void setMail_tail(String mail_tail) {
		this.mail_tail = mail_tail;
	}
	public String getF_postal() {
		return f_postal;
	}
	public void setF_postal(String f_postal) {
		this.f_postal = f_postal;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getF_tell() {
		return f_tell;
	}
	public void setF_tell(String f_tell) {
		this.f_tell = f_tell;
	}
	public String getM_tell() {
		return m_tell;
	}
	public void setM_tell(String m_tell) {
		this.m_tell = m_tell;
	}
	public String getL_tell() {
		return l_tell;
	}
	public void setL_tell(String l_tell) {
		this.l_tell = l_tell;
	}
	public String getBirth_year() {
		return birth_year;
	}
	public void setBirth_year(String birth_year) {
		this.birth_year = birth_year;
	}
	public String getBirth_month() {
		return birth_month;
	}
	public void setBirth_month(String birth_month) {
		this.birth_month = birth_month;
	}
	public String getBirth_day() {
		return birth_day;
	}
	public void setBirth_day(String birth_day) {
		this.birth_day = birth_day;
	}
	public String getCalendar() {
		return calendar;
	}
	public void setCalendar(String calendar) {
		this.calendar = calendar;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getNewletter() {
		return newletter;
	}
	public void setNewletter(String newletter) {
		this.newletter = newletter;
	}
	public String getSms() {
		return sms;
	}
	public void setSms(String sms) {
		this.sms = sms;
	}
	
	
	
	
	
	
}
