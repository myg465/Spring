package com.javalec.ex;


import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.dto.LoginDto;
import com.javalec.ex.dto.MemberDto;
import com.javalec.ex.dto.StudentDto;


@Controller
public class JController {

	@RequestMapping("join02_info_input")
	public String join_input() {
		
		return "join02_info_input";
		
	}
	
	@RequestMapping("join03_success")
	public String join_success(@ModelAttribute("dto") MemberDto memberdto) {
		
		return "join03_success";
		
	}
	//--------------------------------------------------------------
	@RequestMapping("form")
	public String form() {
		return "form";
	}
	
	@RequestMapping("formOk")
	public String formOk(@ModelAttribute("stu") StudentDto studentDto) {
		return "formOk";
	}
	//--------------------------------------------------------------
	
	@RequestMapping("input")
	public String input() {
		return "input";
	}
	
	@RequestMapping("inputOk") // 여기서 유효성 검사를 실시함
	public String inputOk(LoginDto loginDto,BindingResult result) {
		
		String page ="inputOk";
		LoginValidator validator = new LoginValidator();
		
		validator.validate(loginDto, result);
		
		if(result.hasErrors()) {
			page="input";
		}
		
		return page;
	}
	
	
	
}
