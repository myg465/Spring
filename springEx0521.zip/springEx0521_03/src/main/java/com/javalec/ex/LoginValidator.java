package com.javalec.ex;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.javalec.ex.dto.LoginDto;

public class LoginValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return LoginDto.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		LoginDto loginDto = (LoginDto)obj;
		
		if(loginDto.getName()==null || loginDto.getName().trim().isEmpty()) {
			System.out.println("이름 공백 에러");
			errors.rejectValue("name", "이름 공백 에러");
		}
		if(loginDto.getId()==null || loginDto.getId().trim().isEmpty()) {
			System.out.println("아이디 공백 에러");
			errors.rejectValue("id", "아이디 공백 에러");
		}
		if(loginDto.getPw()==null || loginDto.getPw().trim().isEmpty()) {
			System.out.println("비밀번호 공백 에러");
			errors.rejectValue("pw", "비밀번호 공백 에러");
		}
		
		
	}

}
