package com.javalec.ex;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.javalec.ex.dto.BoardDto;

public class BoardValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return BoardDto.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		BoardDto boardDto = (BoardDto)obj;
		
		
		if(boardDto.getB_num()==null || boardDto.getB_num().trim().isEmpty()) {
			errors.rejectValue("b_num", "번호 공백 에러");
		}
		if(boardDto.getB_title()==null || boardDto.getB_title().trim().isEmpty()) {
			errors.rejectValue("b_title", "제목 공백 에러");
		}
		if(boardDto.getB_content()==null || boardDto.getB_content().trim().isEmpty()) {
			errors.rejectValue("b_content", "내용 공백 에러");
		}
		if(boardDto.getB_date()==null || boardDto.getB_date().trim().isEmpty()) {
			errors.rejectValue("b_date", "날짜 공백 에러");
		}
		
		
	}

}
