package com.javalec.ex;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.javalec.ex.dto.Student;

public class FormValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return Student.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		Student student = (Student)obj;
		
		if(student.getName()==null || student.getName().trim().isEmpty()) {
			errors.rejectValue("name", "이름공백에러");
		}
		
		
		
	}

}
