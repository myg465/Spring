package com.javalec.ex.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.command.*;
import com.javalec.ex.util.Constant;

@Controller
public class BController {

	BCommand comm;
	
	//템플릿 선언
	JdbcTemplate template;

	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		Constant.template=this.template;
	}
	
	//-----------------------------------------------------------------
	
	@RequestMapping("list")
	public String list(Model model) {
		
		comm=new BListCommand();
		comm.execute(model);
		
		return "list";
	}//list
	
	//-----------------------------------------------------------------
	
	@RequestMapping("write_view")
	public String write_view(Model model) {
		return "write_view";
	}//write_view
	
	//-----------------------------------------------------------------
	
	@RequestMapping("write")
	public String write(HttpServletRequest request,Model model) {  //작성자,제목,내용이 넘어옴
		
		model.addAttribute("request",request);//리퀘스트를 모델로 넘겨줌
		comm=new BWriteCommand();
		comm.execute(model);
		
		return "redirect:list";
	}//write
	
	//-----------------------------------------------------------------
	
	@RequestMapping("content_view")
	public String content_view(HttpServletRequest request,Model model) {  //list에서 넘어옴(bId로 넘어옴)
		
		model.addAttribute("request",request);
		comm=new BContentCommand();
		comm.execute(model);
		
		return "content_view";
	}//content_view
	
	//-----------------------------------------------------------------
	
	@RequestMapping("modify_view")
	public String modify_view(HttpServletRequest request, Model model) {
		
		model.addAttribute("request",request);
		comm = new BModifyViewCommand();
		comm.execute(model);
		
		return "modify_view";
	}//modify
		
	//-----------------------------------------------------------------
	
	@RequestMapping("modify")
	public String modify(HttpServletRequest request, Model model) {
		
		model.addAttribute("request",request);
		comm=new BModifyCommand();
		comm.execute(model);
		
		return "redirect:list";
	}//modify
	
	//-----------------------------------------------------------------
	
	@RequestMapping("reply_view")
	public String reply_view(HttpServletRequest request, Model model) {
		
		model.addAttribute("request",request);
		comm=new BReplyViewCommand();
		comm.execute(model);
		
		return "reply_view";
	}
	
	//-----------------------------------------------------------------
	
	@RequestMapping("reply")
	public String reply(HttpServletRequest request, Model model) {
		
		model.addAttribute("request",request);
		comm=new BReplyCommand();
		comm.execute(model);
		
		
		return "redirect:list";
	}
	
	//-----------------------------------------------------------------
	
	@RequestMapping("delete")
	public String delete(HttpServletRequest request, Model model) {
		
		model.addAttribute("request",request);
		comm=new BDeleteCommand();
		comm.execute(model);
		
		
		return "redirect:list";
	}
	
	
	
}
