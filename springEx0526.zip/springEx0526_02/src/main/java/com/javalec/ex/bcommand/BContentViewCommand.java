package com.javalec.ex.bcommand;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.javalec.ex.bdao.BDao;
import com.javalec.ex.bdto.BDto;

public class BContentViewCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, Model model) {

		String bId = request.getParameter("bId");
		
		BDao dao = new BDao();
		BDto dto = dao.content_view(bId);
		
		model.addAttribute("content_view",dto);

	}

}
