package com.javalec.ex.bdao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.javalec.ex.bdto.BDto;
import com.javalec.ex.util.Constant;

public class BDao {
	
	public BDao() {
		
		template=Constant.template;
		
	}

	public JdbcTemplate template;
	
	public ArrayList<BDto> list() {
		
		String sql="select * from mvc_board order by bGroup desc, bStep asc";
		return (ArrayList<BDto>) template.query(sql, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}
	
	public BDto content_view(String bId) {
		upHit(bId);
		String sql="select * from mvc_board where bId="+bId;
		return template.queryForObject(sql, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}

	public BDto modify_view(String bId) {
		
		String sql="select * from mvc_board where bId="+bId;
		return template.queryForObject(sql, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}
	
	public void write(final String bName, final String bTitle, final String bContent) {
		
		String sql = "insert into mvc_board(bId,bName,bTitle,bContent,bHit,bGroup,bStep,bIndent)"
				+ "values(mvc_board_seq.nextval,?,?,?,0,mvc_board_seq.currval,0,0)";
		
		template.update(sql,new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bName);
				ps.setString(2, bTitle);
				ps.setString(3, bContent);
				
			}
		});
		
	}
	
	
	public void upHit(String bId) {
		
		String sql ="update mvc_board set bHit=bHit+1 where bId="+bId;
		template.update(sql);
		
	}

	public void delete(String bId) {

		String sql ="delete from mvc_board where bId="+bId;
		template.update(sql);
		
	}

	
	
	
	
	
}//class
