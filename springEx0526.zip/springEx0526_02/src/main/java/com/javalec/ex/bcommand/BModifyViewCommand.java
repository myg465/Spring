package com.javalec.ex.bcommand;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.javalec.ex.bdao.BDao;
import com.javalec.ex.bdto.BDto;

public class BModifyViewCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, Model model) {

		String bId = request.getParameter("bId");
		
		BDao dao = new BDao();
		BDto dto = dao.modify_view(bId);
		
		model.addAttribute("modify_view",dto);

	}

}
