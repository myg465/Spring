package com.javalec.ex;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
public class AppCTX {
	
	@Value("${auth}") // 프로퍼티에서 값을 주입해줌
	private String auth;
	@Value("${driverClassName}")
	private String driverClassName;
	@Value("${url}")
	private String url;
	@Value("${username1}")
	private String username1;
	@Value("${password}")
	private String password;
	@Value("${name}")
	private String name;
	@Value("${type}")
	private String type;
	@Value("${maxAction}")
	private String maxAction;
	@Value("${maxWait}")
	private String maxWait;

	@Bean  //실행되기 전에 실행됨->static메소드
	public static PropertySourcesPlaceholderConfigurer properties() {
		
		PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
		
		Resource[] location = new Resource[2];
		location[0] = new ClassPathResource("server1.properties");
		location[1] = new ClassPathResource("server2.properties");
		//(참고)하나만 있을경우
		//Resource location = new ClassPathResource("server.properties");
		
		configurer.setLocations(location); //배열인 경우
		
		return configurer;
		
	}
	
	@Bean
	public ServerInfo serverInfo() {
		
		ServerInfo serverInfo = new ServerInfo();
		serverInfo.setAuth(auth);
		serverInfo.setDriverClassName(driverClassName);
		serverInfo.setMaxAction(maxAction);
		serverInfo.setMaxWait(maxWait);
		serverInfo.setName(name);
		serverInfo.setPassword(password);
		serverInfo.setType(type);
		serverInfo.setUrl(url);
		serverInfo.setUsername1(username1);
		
		
		return serverInfo;
		
	}
	
}
