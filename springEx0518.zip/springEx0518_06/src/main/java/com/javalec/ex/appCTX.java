package com.javalec.ex;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
public class appCTX {

	@Value("${LINE}")
	private String LINE;
	@Value("${ADRES}")
	private String ADRES;
	@Value("${RDNMADR}")
	private String RDNMADR;
	@Value("${STATN_NM}")
	private String STATN_NM;
	@Value("${TELNO}")
	private String TELNO;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyies() {
		
		PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
		
		Resource location = new ClassPathResource("subway.properties");
		
		configurer.setLocation(location);
		
		return configurer;
	}
	
	
	@Bean
	public SubwayInfo subwayInfo() {
		
		SubwayInfo subwayInfo = new SubwayInfo();
		subwayInfo.setLINE(LINE);
		subwayInfo.setADRES(ADRES);
		subwayInfo.setRDNMADR(RDNMADR);
		subwayInfo.setSTATN_NM(STATN_NM);
		subwayInfo.setTELNO(TELNO);
		
		
		return subwayInfo;
	}
	
}
