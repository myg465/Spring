package com.javalec.ex;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(appCTX.class);
		SubwayInfo subwayInfo = ctx.getBean("subwayInfo",SubwayInfo.class);
		
		System.out.println("LINE : "+subwayInfo.getLINE());
		System.out.println("ADRES : "+subwayInfo.getADRES());
		System.out.println("RDNMADR : "+subwayInfo.getRDNMADR());
		System.out.println("STATN_NM : "+subwayInfo.getSTATN_NM());
		System.out.println("TELNO : "+subwayInfo.getTELNO());

	}

}
