package com.javalec.ex;

public class SubwayInfo {

	private String LINE;
	private String STATN_NM;
	private String ADRES;
	private String RDNMADR;
	private String TELNO;
	
	
	public String getLINE() {
		return LINE;
	}
	public void setLINE(String lINE) {
		LINE = lINE;
	}
	public String getSTATN_NM() {
		return STATN_NM;
	}
	public void setSTATN_NM(String sTATN_NM) {
		STATN_NM = sTATN_NM;
	}
	public String getADRES() {
		return ADRES;
	}
	public void setADRES(String aDRES) {
		ADRES = aDRES;
	}
	public String getRDNMADR() {
		return RDNMADR;
	}
	public void setRDNMADR(String rDNMADR) {
		RDNMADR = rDNMADR;
	}
	public String getTELNO() {
		return TELNO;
	}
	public void setTELNO(String tELNO) {
		TELNO = tELNO;
	}
	
	
	
}
