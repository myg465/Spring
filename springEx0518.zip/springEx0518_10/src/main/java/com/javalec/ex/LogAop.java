package com.javalec.ex;

import org.aopalliance.intercept.Joinpoint;
import org.aspectj.lang.ProceedingJoinPoint;

public class LogAop {

	
	//대행클래스 1번째 메소드(처음과 마지막에 실행되는 메소드)
	public Object loggerAop(ProceedingJoinPoint joinPoint) throws Throwable {
		
		//System.out.println("조인포인트 실행");
		long starttime = System.currentTimeMillis();// 현재시간을 불러옴
		System.out.println(starttime);//메소드 실행전을 출력
		
		try {
			
			return joinPoint.proceed(); //현재 진행하는 프로그램을 실행시켜라
			
		} finally {
			
			long endtime = System.currentTimeMillis();
			System.out.println(endtime);//메소드 실행후를 출력
			System.out.println("-------------------------------");
			
		}
	
	}
	
	//대행클래스 2번째 메소드(처음에 실행되는 메소드)
	public void beforeAdvice(Joinpoint joinpoint) {
		
		System.out.println("처음 실행되는 log");
		
		long starttime = System.currentTimeMillis();// 현재시간을 불러옴
		System.out.println(starttime);//첫시작만 출력
		
	}
	
	//대행클래스 3번째 메소드(마지막에 실행되는 메소드)
	public void afterAdvice(Joinpoint joinpoint) {
		
		System.out.println("마지막에 실행되는 log");
		
	}
	
	
	
	
}
