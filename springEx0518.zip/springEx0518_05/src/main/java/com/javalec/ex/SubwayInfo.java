package com.javalec.ex;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;

public class SubwayInfo implements EnvironmentAware,InitializingBean,DisposableBean{

	private Environment env;
	private String LINE;
	private String STATN_NM;
	private String ADRES;
	private String RDNMADR;
	private String TELNO;
	
	public void setEnvironment(Environment env) {
		System.out.println("setEnvironment()");
		setEnv(env);
		
	}
	
	public String getLINE() {
		return LINE;
	}
	public void setLINE(String lINE) {
		LINE = lINE;
	}
	public String getSTATN_NM() {
		return STATN_NM;
	}
	public void setSTATN_NM(String sTATN_NM) {
		STATN_NM = sTATN_NM;
	}
	public String getADRES() {
		return ADRES;
	}
	public void setADRES(String aDRES) {
		ADRES = aDRES;
	}
	public String getRDNMADR() {
		return RDNMADR;
	}
	public void setRDNMADR(String rDNMADR) {
		RDNMADR = rDNMADR;
	}
	public String getTELNO() {
		return TELNO;
	}
	public void setTELNO(String tELNO) {
		TELNO = tELNO;
	}
	
	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("afterPropertiesSet()");
		setLINE(env.getProperty("LINE"));
		setSTATN_NM(env.getProperty("STATN_NM"));
		setADRES(env.getProperty("ADRES"));
		setRDNMADR(env.getProperty("RDNMADR"));
		setTELNO(env.getProperty("TELNO"));
	}
	
	public void destroy() throws Exception {
		System.out.println("destroy()");
		
	}
	
	
	
	
	
	
	
	
}
