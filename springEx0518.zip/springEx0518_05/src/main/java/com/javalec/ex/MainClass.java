package com.javalec.ex;

import java.io.IOException;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.io.support.ResourcePropertySource;

public class MainClass {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = new GenericXmlApplicationContext();
		ConfigurableEnvironment env = ctx.getEnvironment();
		MutablePropertySources propertySources= env.getPropertySources();
		
		try {
			propertySources.addLast(new ResourcePropertySource("classpath:subway.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		GenericXmlApplicationContext ctx2 = (GenericXmlApplicationContext)ctx;
		ctx2.load("appCTX.xml");
		ctx2.refresh();
		SubwayInfo subwayInfo = ctx2.getBean("subwayInfo",SubwayInfo.class);
		System.out.println("LINE : "+subwayInfo.getLINE());
		System.out.println("STATN_NM : "+subwayInfo.getSTATN_NM());
		System.out.println("ADRES : "+subwayInfo.getADRES());
		System.out.println("RDNMADR : "+subwayInfo.getRDNMADR());
		System.out.println("TELNO : "+subwayInfo.getTELNO());
		

	}

}
