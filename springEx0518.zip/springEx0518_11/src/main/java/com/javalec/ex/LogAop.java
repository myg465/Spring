package com.javalec.ex;

import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;

public class LogAop {

	public Object loggerAop(ProceedingJoinPoint joinpoint) throws Throwable {
		
		Date starttime= new Date();
		System.out.println(starttime.getTime());
		
		try {
			
			return joinpoint.proceed();
		} 
		finally {
			Date endtime=new Date();
			System.out.println(endtime.getTime());
			System.out.println("---------------------------");
		}
		
		
	}
	
	
	
}
