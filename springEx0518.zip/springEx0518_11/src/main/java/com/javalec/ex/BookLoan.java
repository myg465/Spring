package com.javalec.ex;

import java.util.Date;

public class BookLoan {

	public BookLoan() {}
	
	private String stuNum;
	private String bookNum;
	private String bookName;
	private String category;
	private String loandate;
	private String returndate;
	private String latedate;
	
	public String getStuNum() {
		return stuNum;
	}
	public void setStuNum(String stuNum) {
		this.stuNum = stuNum;
	}
	public String getBookNum() {
		return bookNum;
	}
	public void setBookNum(String bookNum) {
		this.bookNum = bookNum;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLoandate() {
		return loandate;
	}
	public void setLoandate(String loandate) {
		this.loandate = loandate;
	}
	public String getReturndate() {
		return returndate;
	}
	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}
	public String getLatedate() {
		return latedate;
	}
	public void setLatedate(String latedate) {
		this.latedate = latedate;
	}
	
	public void getbookLoan() {
		System.out.println("도서번호 : "+ getBookNum());
		System.out.println("도서제목 : "+ getBookName());
		System.out.println("분류 : "+ getCategory());
		System.out.println("대출일자 : "+ getLoandate());
		System.out.println("반납일자 : "+ getReturndate());
		System.out.println("연체일 : "+ getLatedate());
		
	}
	
	
	
}
