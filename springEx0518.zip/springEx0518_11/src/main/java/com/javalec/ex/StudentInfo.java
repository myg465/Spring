package com.javalec.ex;

public class StudentInfo {

	
	private String stuNum;
	private String stuName;
	private String stuMajor;
	private String stuAddress;
	private String stuTel;
	
	
	public String getStuNum() {
		return stuNum;
	}
	public void setStuNum(String stuNum) {
		this.stuNum = stuNum;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuMajor() {
		return stuMajor;
	}
	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
	public String getStuAddress() {
		return stuAddress;
	}
	public void setStuAddress(String stuAddress) {
		this.stuAddress = stuAddress;
	}
	public String getStuTel() {
		return stuTel;
	}
	public void setStuTel(String stuTel) {
		this.stuTel = stuTel;
	}
	
	public void getstuInfo() {
		System.out.println("학번 : "+getStuNum());
		System.out.println("학생이름 : "+getStuName());
		System.out.println("학과 : "+getStuMajor());
		System.out.println("주소 : "+getStuAddress());
		System.out.println("전화번호 : "+getStuTel());
	}
	
	
	
	
}
