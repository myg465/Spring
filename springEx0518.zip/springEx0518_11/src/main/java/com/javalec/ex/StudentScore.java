package com.javalec.ex;

public class StudentScore {

	public StudentScore() {}
	
	
	public StudentScore(String stuNum, int kor, int eng, int math) {
		this.stuNum = stuNum;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
		this.total = kor+eng+math;
		this.avg = total/3.0;
	}


	private String stuNum;
	private int kor;
	private int eng;
	private int math;
	private int total;
	private double avg;
	public String getStuNum() {
		return stuNum;
	}


	public void setStuNum(String stuNum) {
		this.stuNum = stuNum;
	}


	public int getKor() {
		return kor;
	}


	public void setKor(int kor) {
		this.kor = kor;
	}


	public int getEng() {
		return eng;
	}


	public void setEng(int eng) {
		this.eng = eng;
	}


	public int getMath() {
		return math;
	}


	public void setMath(int math) {
		this.math = math;
	}


	public int getTotal() {
		return total;
	}


	public void setTotal(int total) {
		this.total = total;
	}


	public double getAvg() {
		return avg;
	}


	public void setAvg(double avg) {
		this.avg = avg;
	}
	
	public void getstuScore() {
		
		System.out.println("국어성적 : "+ getKor());
		System.out.println("영어성적 : "+ getEng());
		System.out.println("수학성적 : "+ getMath());
		System.out.println("합계 : "+ getTotal());
		System.out.println("평균 : "+ getAvg());
		
	}
	
	
	
}
