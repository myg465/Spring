package com.javalec.ex;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ctx.load("appCTX.xml");
		ctx.refresh();
		
		AdminConnection adminconnection = ctx.getBean("adminConnection",AdminConnection.class);
		
		System.out.println("adminId : "+adminconnection.getAdminId());
		System.out.println("adminPw : "+adminconnection.getAdminPw());
		System.out.println("sub_adminId : "+adminconnection.getSub_adminId());
		System.out.println("sub_adminPw : "+adminconnection.getSub_adminPw());
		
		ctx.close();

	}

}
