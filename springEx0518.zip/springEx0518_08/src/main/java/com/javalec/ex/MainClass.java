package com.javalec.ex;

import java.util.Scanner;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		String config="";
		System.out.println("접속환경을 선택해 주세요. 1) pc 2) 태블릿 3) 모바일");
		
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		switch(num) {
		
			case 1:
				config="window";
				break;
			case 2:
				config="tablet";
				break;
				
			case 3:
				config="mobile";
				break;
		}
		
		scan.close();
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ctx.getEnvironment().setActiveProfiles(config);
		ctx.load("appCTX1.xml","appCTX2.xml","appCTX3.xml");
		ctx.refresh();
		
		ConnectType connectType = ctx.getBean("connectType",ConnectType.class);
		System.out.println("접속기기 : "+ connectType.getOperator());
		System.out.println("브라우저 : "+ connectType.getBrowser());
		System.out.println("접속ip : "+ connectType.getIp());
		System.out.println("접속환경 : "+ connectType.getConnect());
		
		ctx.close();
		
		
		

	}

}
