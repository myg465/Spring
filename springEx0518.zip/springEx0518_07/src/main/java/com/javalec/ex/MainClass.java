package com.javalec.ex;

import java.util.Scanner;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		String config="";
		System.out.println(" 서버를 선택해 주세요. 1) test-server 2) 실제-server ");
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		
		switch(num) {
			case 1:
				config="test";
				break;
			
			case 2:
				config="server";
				break;
		
		}//switch
		
		scan.close(); //스캔도 닫아 줘야함
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ctx.getEnvironment().setActiveProfiles(config);// 프로파일명을 넣어줌
		ctx.load("appCTX1.xml","appCTX2.xml"); //두개를 넣어놓음(따로따로 콤마로 구분해서 넣어주기)
		ctx.refresh();
		
		ServerInfo serverInfo = ctx.getBean("serverInfo",ServerInfo.class);
		
		System.out.println("서버 접속 완료");
		System.out.println("접속ip : "+serverInfo.getIpNum());
		System.out.println("접속port : "+serverInfo.getPortNum());
		System.out.println("------------------------------------");
		System.out.println("url : "+serverInfo.getIpNum()+":"+serverInfo.getPortNum());
		
		ctx.close();
		

	}

}
