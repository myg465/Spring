package com.javalec.ex;

import java.util.ArrayList;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx=new GenericXmlApplicationContext("classpath:appCTX.xml");
		
		Stu_Info stuInfo=ctx.getBean("stuInfo",Stu_Info.class); //stuInfo->arraylist(Student)
		ArrayList<Student> list=stuInfo.getList();
		
		Stu_score stu_score3 = ctx.getBean("stu_score3",Stu_score.class);
		
		for(int i=0;i<list.size();i++) {
			Student stu=list.get(i);
			if(stu_score3.stu_num==stu.stu_num) {
				System.out.println("<<"+stu.stu_name+"학생성적출력>>");
				stu.getprint();
				System.out.println("================================");
				stu_score3.getprint();
			}//if
		}//for
		

	}//main

}//class
