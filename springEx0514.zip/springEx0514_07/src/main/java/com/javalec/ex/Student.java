package com.javalec.ex;

public class Student {

	//학번,이름,전공,주소,전화번호
	int stu_num;
	String stu_name;
	String stu_major;
	String stu_address;
	String stu_tel;
	
	public Student() {}

	public Student(int stu_num, String stu_name, String stu_major, String stu_address, String stu_tel) {
		this.stu_num = stu_num;
		this.stu_name = stu_name;
		this.stu_major = stu_major;
		this.stu_address = stu_address;
		this.stu_tel = stu_tel;
	}

	public void getprint() {
		System.out.println("학생번호: "+stu_num);
		System.out.println("학생이름: "+stu_name);
		System.out.println("학생전공: "+stu_major);
		System.out.println("학생주소: "+stu_address);
		System.out.println("학생전화: "+stu_tel);
		
	}
	
	
	public int getStu_num() {
		return stu_num;
	}

	public void setStu_num(int stu_num) {
		this.stu_num = stu_num;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public String getStu_major() {
		return stu_major;
	}

	public void setStu_major(String stu_major) {
		this.stu_major = stu_major;
	}

	public String getStu_address() {
		return stu_address;
	}

	public void setStu_address(String stu_address) {
		this.stu_address = stu_address;
	}

	public String getStu_tel() {
		return stu_tel;
	}

	public void setStu_tel(String stu_tel) {
		this.stu_tel = stu_tel;
	}
	
	
	
}
