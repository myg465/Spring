package com.javalec.ex;

public class Stu_score {

	//학번,국어,영어,수학,합계,평균
	int stu_num;
	int kor;
	int eng;
	int math;
	int total;
	double avg;
	
	public Stu_score() {}

	public Stu_score(int stu_num, int kor, int eng, int math) {
		this.stu_num = stu_num;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
		this.total = kor+eng+math;
		this.avg = total/3.0;
	}

	public void getprint() {
		System.out.println("국어성적: "+kor);
		System.out.println("영어성적: "+eng);
		System.out.println("수학성적: "+math);
		System.out.println("합계: "+total);
		System.out.println("평균: "+avg);
		
	}
	
	public int getStu_num() {
		return stu_num;
	}

	public void setStu_num(int stu_num) {
		this.stu_num = stu_num;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}
	
	
}
