package com.javalec.ex;

public class Student {

	Student(){}
	
	public Student(int stu_num, String stu_name, int kor, int eng, int math) {
		this.stu_num = stu_num;
		this.stu_name = stu_name;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
		this.total = kor+eng+math;
		this.avg = total/3.0;
	}

	int stu_num;
	String stu_name;
	int kor;
	int eng;
	int math;
	int total;
	double avg;
	
	public void setStu_num(int stu_num) {
		this.stu_num = stu_num;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	
	public String toString() {
		return "학번 : "+stu_num+" ,이름 : "+stu_name+" ,국어성적 : "+kor+
				"\n ,영어성적 : "+eng+" ,수학성적 : "+math+" ,합계 : "+total+" ,평균 : "+avg+"\n============================================";
	}
	
	
	
	
	
}
