package com.javalec.ex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppCtx {

	@Bean
	public Student student1() {
		
		Student student1 = new Student(1001, "홍길동", 90, 70, 70);
		
		return student1;
	}
	
	@Bean
	public Student student2() {
		
		Student student2 = new Student(1002, "김유신", 70, 40, 80);
		
		return student2;
	}
	
	
}
