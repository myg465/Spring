package com.javalec.ex;

public interface Avante {

	public void basic();
	public void option();
	
}
