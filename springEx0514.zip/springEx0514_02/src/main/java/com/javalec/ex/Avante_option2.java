package com.javalec.ex;

public class Avante_option2 implements Avante {

	public void basic() {
		System.out.println("기본 구성 : 가솔린엔진,디스크브레이크");
	}

	public void option() {
		System.out.println("옵션 :  door_sheet(인조가죽), highpass(하이패스)+ecm룸미러");
	}

}
