package com.javalec.ex;

public class StudentInfo {

	
	public StudentInfo() {}
	
	//생성자로 객체를 받음
	public StudentInfo(Student student) {
		this.student=student;
	}

	private Student student;
	
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	
}
