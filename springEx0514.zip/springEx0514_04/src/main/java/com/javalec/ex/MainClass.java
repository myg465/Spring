package com.javalec.ex;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		//AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:appCTX.xml");
		
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppCtx.class); //ctx를 부르는 방법만 다름
		
		Student student1 = ctx.getBean("student1",Student.class);
		
		System.out.println("학생1 이름 : "+student1.getName());
		System.out.println("학생1 나이 : "+student1.getAge()); 
		System.out.println("학생1 취미 : "+student1.getHobbys()); 
		System.out.println("학생1 키 : "+student1.getHeight()); 
		System.out.println("학생1 몸무게 : "+student1.getWeight()); 

	}

}
